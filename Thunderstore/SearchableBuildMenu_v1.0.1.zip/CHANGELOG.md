| `Version` | `Update Notes`                                                    |
|-----------|-------------------------------------------------------------------|
| 1.0.1     | - Fix some logging. Guess I forgot to wrap that in #if DEBUG lmao |
| 1.0.0     | - Initial Release                                                 |