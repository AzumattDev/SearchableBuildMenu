| `Version` | `Update Notes`                                                                                                          |
|-----------|-------------------------------------------------------------------------------------------------------------------------|
| 1.0.2     | - I had it on the mod page, but hadn't implemented it yet. Implement a clear `X` button for easy clearing of the field. |
| 1.0.1     | - Fix some logging. Guess I forgot to wrap that in #if DEBUG lmao                                                       |
| 1.0.0     | - Initial Release                                                                                                       |